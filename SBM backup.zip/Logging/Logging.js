const fs = require('fs');

function Logging() {}

Logging.prototype.addToLogFile = function(str) {
    
};

module.exports = Logging;