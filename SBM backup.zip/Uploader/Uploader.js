function Uploader() {

    uploadWeather();
    uplodateRaspberry();
    
}
module.exports = Uploader;